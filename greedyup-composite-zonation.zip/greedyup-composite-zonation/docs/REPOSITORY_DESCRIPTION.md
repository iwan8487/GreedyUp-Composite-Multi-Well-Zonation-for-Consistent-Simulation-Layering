# Repository description texts

Ready-to-paste texts for GitHub, GitLab, Zenodo or a journal's code-availability statement.

## 1. Repository name (suggestions)

* `greedyup-composite-zonation`
* `composite-multiwell-zonation`

## 2. Short description ("About" field, ≤ 350 characters)

**English (287 characters)**
> Composite multi-well zonation that builds one laterally consistent set of reservoir-simulation layers from core/log data of many wells. It includes an offline browser app, a Python reference implementation with single-phase flow validation, and the data, figures and tables of the paper.

**Bahasa Indonesia**
> Zonasi multi-sumur komposit untuk membangun satu set lapisan simulasi reservoir yang konsisten secara lateral dari data core/log banyak sumur. Berisi aplikasi browser offline, implementasi referensi Python dengan validasi aliran satu fase, serta data, gambar, dan tabel paper.

## 3. Topics / keywords

`reservoir-simulation` `zonation` `upscaling` `uplayering` `well-logs` `petrophysics` `reservoir-characterization` `grid-coarsening` `pareto-front` `finite-volume` `las-files` `geoscience` `petroleum-engineering` `python` `javascript`

## 4. Long description (Zenodo, ~170 words)

GreedyUp is software for selecting reservoir-simulation layers directly from the core or log data of several wells. It extends a greedy, threshold-based single-well zonation to a composite formulation. The moving-window heterogeneity of log2-permeability in each well is resampled onto a common relative stratigraphic coordinate and aggregated across wells (maximum, P90 or mean). The aggregated curve is segmented once, and the boundaries are transferred proportionally to each well, so that all wells share the same zones in the same stratigraphic order. A grid search over the zonation threshold and window size gives the Pareto front of shared zone count versus worst-well fidelity. The grids are validated with a two-dimensional single-phase finite-volume simulator against a 382-layer benchmark, for all producer-well combinations and under geometric or arithmetic/harmonic permeability averaging. The record contains a self-contained HTML/JavaScript application that runs offline, a Python reference implementation (NumPy, SciPy, lasio) with a command-line pipeline that reproduces the results of the accompanying paper, and the result tables and figures.

## 5. Code and data availability statement (for the paper)

> The interactive application and the Python implementation used in this study are openly available at [repository URL] and archived at [Zenodo DOI]. The core data of the 17 wells are [available from the corresponding author on reasonable request / archived at …, subject to the data owner's permission].
