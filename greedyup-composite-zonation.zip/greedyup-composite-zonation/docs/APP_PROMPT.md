# Prompt: GreedyUp interactive application (version 2)

This file contains a self-contained prompt for an AI coding assistant or a developer to maintain, fix or rebuild the GreedyUp browser application. Paste section A as the instruction and attach the current file `app/consistent_grid_explorer.html` (and, if possible, `python/zonation_core.py` as the numerical reference). Section B is a shorter version for small tasks.

---

## A. Full prompt

### Role and goal

You are a scientific software engineer working on GreedyUp, a single-file HTML/JavaScript application for composite multi-well zonation of reservoir core or log data. Produce **version 2** of the attached application. Version 2 must fix the known defects listed below, add the listed features and keep every existing feature working. Its numerical results must match the Python reference implementation `zonation_core.py` within the stated tolerances.

### Hard constraints

1. One self-contained `.html` file. No external scripts, fonts, CDNs or network requests; the file must run offline by double-clicking.
2. Plain JavaScript (ES2020) and inline SVG/Canvas. No frameworks or build step.
3. Keep the embedded demo data set (`HW_DATA`, four wells HW-7, HW-29, HW-32, HW-28) byte-identical, so that results remain comparable with the paper.
4. Keep the visual style, panel layout and export functions (PNG at 1×–6× and 150–1,200 dpi, SVG, CSV, JSON).
5. The user interface must stay responsive. Run the flow simulation and the grid search in chunks (`setTimeout`/`requestAnimationFrame`) or in a Web Worker created from a Blob URL, and show a progress indicator.
6. Comment every numerical function with its equation and units.

### What the application does (current behaviour to preserve)

**Data input.** It uses the demo data or uploaded LAS 2.0 files (multiple) plus a delimited well-top file with the columns `Well identifier, Surface, X, Y, Z, MD`. Depth, permeability and porosity curves are detected by mnemonic, and the user selects the top and base surfaces. Each well is clipped to [top, base], and null values are filled by interpolation over depth (log2 space for permeability) and clamped to the well's observed range. Wells are ordered west to east by X, and the section distance is the cumulative straight-line path between consecutive wells. Wells can be selected on a map.

**Composite zonation.** With defaults N_T = 1000, f_W = 2%, c = 0.5, L_min = 5, L_max = 40 and aggregator = max:

1. t = (MD − MD_top) / (MD_base − MD_top); resample log2K of each well to `t_i = i/(N_T−1)` with clamped linear interpolation.
2. H_w = moving standard deviation of the resampled log2K, window W = max(3, round(f_W·N_T)), mirrored padding (population s.d.).
3. H = max | P90 | mean over wells. P90 takes the sorted value at index min(N−1, ceil(0.9N)−1).
4. Greedy scan of H: starting at i, extend the width w from L_min while RMSE(H[i:i+w]) < E_z = c·sd(H) and w ≤ L_max. Close the zone at the last width that satisfied the rule (or at L_min if none did), and continue at i + w.
5. Zone boundaries t_z = t at each zone start, plus 1.0. Per-well depths are MD_top + t_z (MD_base − MD_top).
6. Zone properties come from the native samples within [MD_z, MD_z+1) (the last zone includes its base): porosity is the arithmetic mean; permeability follows the averaging rule (see Feature 1). Zones without samples are filled by linear interpolation/extrapolation of zone log2K and porosity on the zone mid-point t, clamped to the well's range.
7. Static fidelity per well is the Pearson r between the native log2K and the log2 of the zone permeability assigned to each sample; the worst-well r is the minimum over wells.

**Parameter optimization.** The grid search runs over c ∈ linspace(c_min, c_max, n) and f_W ∈ linspace(min, max, m) (default 0.15–1.00 × 8, 1–5% × 8). The Pareto front minimises zone count and maximises worst-well r.

**Flow simulation.** The model is a 2-D cross-section (lateral columns × layers) with single-phase, slightly compressible flow, cell-centred finite volumes, two-point fluxes with harmonic inter-cell permeability, and backward Euler. Units are oilfield: β = 0.001127, α = 5.615. Zone log2K and porosity are interpolated linearly between wells and extrapolated linearly beyond the outer wells by a user margin (default 1,000 m); porosity is clamped to [0.01, 0.45]. Layer thickness is the mean of the wells' zone thicknesses. Producer rate is allocated to layers ∝ k_h·h of the well column, and the well pressure is the k_h·h-weighted column average. Defaults: μ = 1 cP, c_t = 1e-5 psi⁻¹, p_0 = 5,000 psi, out-of-plane width 500 ft. The time steps are logarithmically spaced. The current solver is a matrix-free Jacobi-preconditioned CG with warm start.

### Defects to fix

| # | Defect | Location | Required fix |
|---|---|---|---|
| D1 | The fine-grid layer thickness is `depth[e] − depth[s]`, which drops one sample interval per layer; the benchmark becomes 26–28% thinner than the interval | `buildFineZoneTableForWell` | Build the benchmark as N_fine proportional layers uniform in t (as in `zonation_core.uniform_grid`), with thickness = interval thickness / N_fine. Use the same sample-assignment rule as for coarse zones. |
| D2 | The benchmark uses equal-sample-count bins, so benchmark layers and coarse zones do not refer to the same stratigraphic positions in wells with incomplete core coverage | `buildFineZoneTableForWell` | Covered by D1: t-aligned benchmark layers. |
| D3 | The same permeability is used for horizontal and vertical transmissibility | `flowBuildOperator` | Carry separate `kMap` (k_h) and `kvMap` (k_v); use k_h for Tx and k_v for Tz. |
| D4 | The JSON parameter export has no matching import | export panel | Add *Import config (JSON)*, which validates the fields and the version and restores all controls. |
| D5 | The P90 label suggests a distinct aggregator for small well sets | aggregator control | Show the note "P90 = max for ≤ 9 wells" when N ≤ 9. |

### Features to add

1. **Averaging rule selector** with *Geometric* (k_h = k_v = 2^mean(log2 k), legacy) and *Flow-consistent* (k_h = arithmetic mean, k_v = harmonic mean, the new default). Apply the selected rule to both the coarse grids and the benchmark. Show the rule in every figure caption and exported file name.
2. **L_max diagnostic.** In the shared-zonation panel, report the number and percentage of zones whose width equals L_max, and shade those zones on the composite-heterogeneity plot. Show a warning when the percentage exceeds 50% ("layering is close to uniform").
3. **Uniform baseline.** Add a button that inserts a uniform (proportional) grid with the same zone count into the comparison set.
4. **Error metrics.** For each grid and well, report RMSE (psi), the maximum absolute difference and the normalised RMSE = 100 · RMSE / max(p_0 − p_fine) (% of benchmark drawdown). Also report the column flow-capacity deficit D_w = 100 · [1 − Σ k_z h_z / (h_w · mean(k_i))].
5. **Producer-set batch.** Add an option to run all 2^N − 1 producer subsets, factorising (or preconditioning) once per time step and reusing it for all subsets. Show a heat map of normalised RMSE by grid and producer set.
6. **Boundary-agreement check.** Run the single-well rule on each well alone and report the pairwise fraction of boundaries matched within ±5 t-samples.
7. **Results export.** Export the comparison results as CSV with the same column names as `reproduce_results.py` (`avg, method, nZones, combo, well, role, rmse, fine_dd_max, nrmse`).

### Acceptance tests (demo data, defaults)

| Test | Expected |
|---|---|
| Composite zone count | 33 |
| Worst-well r (HW-7) | 0.835 ± 0.001; HW-29 0.875, HW-32 0.899, HW-28 0.896 |
| Zones at L_max | 18 of 33 |
| Grid search 8 × 8 | 64 evaluations, zone counts 25–120, 19 Pareto points |
| 25-zone grids | all zones at L_max (identical to the uniform grid) |
| Independent zonation | 38, 35, 36, 33 zones; mean pairwise agreement 0.34 |
| Benchmark total thickness | equal to each well's interval thickness (HW-7: 148.48 ft) |
| Flow, flow-consistent rule, 25 zones, 400 columns, 50 steps 0.05–2,000 d, 100 bbl/d per producer, mean over 15 producer sets | producer nRMSE 1.16% ± 0.05 |
| Flow, same settings, 120 zones | producer nRMSE 0.075% ± 0.01 |
| Flow, geometric rule, 25 zones | producer nRMSE 6.49% ± 0.2 |

Report the outcome of each test in a short table at the end of your answer.

### Deliverables

1. The complete version-2 HTML file.
2. A change log listing every function that was changed or added, with one sentence per change.
3. The acceptance-test table with the obtained values.

---

## B. Short prompt (for small tasks)

> You are editing GreedyUp, a single-file offline HTML/JavaScript application (no external libraries) for composite multi-well zonation of core permeability data. Keep the embedded demo data, the existing panels and the export functions unchanged. Task: [describe the task]. After the change, the demo data with default parameters must still give 33 shared zones and a worst-well Pearson r of 0.835. Return the full modified file and a list of the changed functions.
