#!/usr/bin/env python
"""reproduce_results.py - reproduce the static and dynamic results of the
composite multi-well zonation study from LAS files and a well-top file.

Examples
--------
python reproduce_results.py --las-dir data/las --welltops data/welltop.txt --out results
python reproduce_results.py --app-html app/consistent_grid_explorer.html --out results   # exact paper data
python reproduce_results.py --las-dir data/las --welltops data/welltop.txt --quick        # fast smoke test
"""
import argparse, glob, itertools, json, os, re, time
import sys
import numpy as np, pandas as pd
from scipy.stats import wilcoxon
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import zonation_core as zc

FT_PER_M = 3.280839895
SECTION_WELLS = ["HW-7", "HW-29", "HW-32", "HW-28"]
# The eight validation grids of the paper (Table 4), given as indices into the
# 8 x 8 search grid c = linspace(0.15, 1.00, 8), f_W = linspace(1, 5, 8) %, so that
# the exact floating-point values of the search are reused.
EZ_GRID = np.linspace(0.15, 1.0, 8); WF_GRID = np.linspace(1.0, 5.0, 8)
PAPER_GRIDS = [(EZ_GRID[i], WF_GRID[j]) for i, j in
               [(7, 3), (4, 2), (4, 1), (0, 7), (2, 0), (1, 0), (0, 1), (0, 0)]]   # 25 ... 120 zones

# ------------------------------------------------------------------ data
def read_welltops(path, top="H2 Top", base="H2 Base"):
    wt = pd.read_csv(path, sep=None, engine="python")
    wt.columns = [c.strip() for c in wt.columns]
    wcol = [c for c in wt.columns if c.lower().startswith("well")][0]
    out = {}
    for w, g in wt.groupby(wcol):
        g = g.set_index("Surface")
        if top in g.index and base in g.index:
            out[str(w)] = dict(top=float(g.loc[top, "MD"]), base=float(g.loc[base, "MD"]),
                               x=float(g.loc[top, "X"]), y=float(g.loc[top, "Y"]))
    return out

def _fill(x, v, log):
    y = np.where(np.isfinite(v) & ((v > 0) if log else True), np.log2(np.where(v > 0, v, 1)) if log else v, np.nan)
    ok = np.isfinite(y)
    if (~ok).any() and ok.sum() > 1:
        y[~ok] = np.clip(np.interp(x[~ok], x[ok], y[ok]), y[ok].min(), y[ok].max())
    return 2 ** y if log else y

def load_las_wells(las_dir, tops, perm="CORE_PERM", por="CORE_POR"):
    import lasio
    wells = {}
    for f in sorted(glob.glob(os.path.join(las_dir, "**", "*.las"), recursive=True)):
        name = os.path.splitext(os.path.basename(f))[0]
        if name not in tops or name in wells:
            continue
        df = lasio.read(f).df()
        t, b = tops[name]["top"], tops[name]["base"]
        h = df[(df.index >= t - 1e-6) & (df.index <= b + 1e-6)]
        valid = np.where(h[perm].notna())[0]
        if len(valid) < 5:
            continue
        h = h.iloc[valid[0]:valid[-1] + 1]
        d = h.index.values.astype(float)
        wells[name] = dict(depth=d, k=_fill(d, h[perm].values.astype(float), True),
                           por=_fill(d, h[por].values.astype(float), False), h2_top=t, h2_base=b)
    return wells

def load_app_wells(html_path):
    html = open(html_path, encoding="utf-8", errors="ignore").read()
    i = html.find("HW_DATA = {"); j = html.find("\n", i)
    hw = json.loads(html[i + len("HW_DATA = "):j].rstrip().rstrip(";"))
    wells = {n: dict(depth=np.array(w["depth"], float), k=np.array(w["k"], float),
                     por=np.array([np.nan if v is None else v for v in w["por"]], float),
                     h2_top=w["h2_top"], h2_base=w["h2_base"]) for n, w in hw["wells"].items()}
    sec = {n: w["section_dist"] for n, w in hw["wells"].items()}
    return wells, hw["order"], sec

def section_distance(order, tops):
    d, cum = {order[0]: 0.0}, 0.0
    for a, b in zip(order[:-1], order[1:]):
        cum += np.hypot(tops[b]["x"] - tops[a]["x"], tops[b]["y"] - tops[a]["y"]); d[b] = cum
    return d

# ------------------------------------------------------------------ static
def front(df):
    df = df.sort_values(["nZones", "minR"], ascending=[True, False]); out, best = [], -1
    for _, r in df.iterrows():
        if r.minR > best: out.append(r); best = r.minR
    return pd.DataFrame(out)

def grid_search(wells, order, agg="max"):
    rows = []
    for ez in EZ_GRID:
        for wf in WF_GRID:
            g = zc.run_composite(wells, order, wf=wf / 100, ezf=ez, agg=agg)
            rs = [g["fid"][n][0] for n in order]
            rows.append(dict(agg=agg, ez=ez, wf=wf, nZones=g["nZones"], minR=min(rs), meanR=float(np.mean(rs)),
                             fracLmax=float(np.mean([b[1] - b[0] + 1 == 40 for b in g["bounds"]]))))
    return pd.DataFrame(rows)

def boundary_agreement(wells, order, tol=5):
    b = {n: np.array([x[0] for x in zc.run_composite(wells, [n])["bounds"]][1:]) for n in order}
    return pd.DataFrame([(a, c, np.mean([np.min(np.abs(b[c] - x)) <= tol for x in b[a]]))
                         for a in order for c in order if a != c], columns=["wellA", "wellB", "agreement"])

def lorenz(k, phi, h):
    k, phi, h = map(lambda v: np.asarray(v, float), (k, phi, h))
    o = np.argsort(-(k / np.maximum(phi, 1e-4)))
    F = np.concatenate([[0], np.cumsum((k * h)[o])]); F /= F[-1]
    P = np.concatenate([[0], np.cumsum((phi * h)[o])]); P /= P[-1]
    return 2 * (np.trapezoid(F, P) - 0.5)

# ------------------------------------------------------------------ dynamic
def flow_batch(wells, order, sec, grids, ncols=400, nsteps=50, rate=-100.0):
    combos = [c for r in range(1, len(order) + 1) for c in itertools.combinations(order, r)]
    rows = []
    for avg in ("geo", "arith"):
        fine = zc.uniform_grid(wells, order, 382, avg=avg)
        Mf = zc.property_maps(fine["zt"], order, sec, ncols, 1000 * FT_PER_M)
        _, hf = zc.simulate(Mf, combos, rate=rate, nsteps=nsteps)
        for ez, wf in grids:
            g = zc.run_composite(wells, order, wf=wf / 100, ezf=ez, avg=avg)
            for meth, gg in (("composite", g), ("uniform", zc.uniform_grid(wells, order, g["nZones"], avg=avg))):
                Mc = zc.property_maps(gg["zt"], order, sec, ncols, 1000 * FT_PER_M)
                _, hc = zc.simulate(Mc, combos, rate=rate, nsteps=nsteps)
                for ci, cb in enumerate(combos):
                    for w in order:
                        e = hc[w][:, ci] - hf[w][:, ci]; dd = 5000 - hf[w][:, ci]
                        rows.append(dict(avg=avg, method=meth, nZones=g["nZones"], combo="+".join(cb), well=w,
                                         role="producer" if w in cb else "observation", rmse=np.sqrt(np.mean(e ** 2)),
                                         fine_dd_max=dd.max(), nrmse=100 * np.sqrt(np.mean(e ** 2)) / max(dd.max(), 1e-9)))
        print(f"  flow batch, {avg} averaging done")
    return pd.DataFrame(rows)

def summarise(R):
    P = R[R.role == "producer"].groupby(["avg", "method", "nZones", "combo"])[["rmse", "nrmse"]].mean().reset_index()
    out = []
    for (avg, nz), g in P.groupby(["avg", "nZones"]):
        a = g[g.method == "composite"].sort_values("combo"); u = g[g.method == "uniform"].sort_values("combo")
        diff = a.rmse.values - u.rmse.values
        p = wilcoxon(a.rmse.values, u.rmse.values).pvalue if np.any(diff != 0) else 1.0
        out.append(dict(avg=avg, nZones=nz, comp_nrmse=a.nrmse.mean(), unif_nrmse=u.nrmse.mean(),
                        advantage_pct=100 * (1 - a.rmse.mean() / u.rmse.mean()), wins=int((diff < 0).sum()), p=p))
    return pd.DataFrame(out)

# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--las-dir"); ap.add_argument("--welltops"); ap.add_argument("--app-html")
    ap.add_argument("--wells", default=",".join(SECTION_WELLS))
    ap.add_argument("--out", default="results"); ap.add_argument("--quick", action="store_true")
    ap.add_argument("--skip-flow", action="store_true")
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); t0 = time.time()
    sel = [w.strip() for w in a.wells.split(",")]
    if a.app_html:
        wells, order, sec = load_app_wells(a.app_html); allw = None
    else:
        tops = read_welltops(a.welltops); allw = load_las_wells(a.las_dir, tops)
        order = sorted([w for w in sel if w in allw], key=lambda n: tops[n]["x"])
        wells = {n: allw[n] for n in order}; sec = section_distance(order, tops)
    print("section wells:", order)
    d = zc.run_composite(wells, order)
    fid = {n: round(d["fid"][n][0], 3) for n in order}
    capped = int(sum(b[1] - b[0] + 1 == 40 for b in d["bounds"]))
    print(f"default composite: {d['nZones']} zones, worst-well r = {min(fid.values()):.3f}, {capped} zones at Lmax; {fid}")
    agr = boundary_agreement(wells, order); agr.to_csv(os.path.join(a.out, "independent_zonation_agreement.csv"), index=False)
    print(f"independent zonation boundary agreement: mean {100*agr.agreement.mean():.0f}%")
    G = grid_search(wells, order); G.to_csv(os.path.join(a.out, "gridsearch.csv"), index=False)
    print(f"grid search: {len(G)} combinations, {len(front(G))} Pareto-optimal")
    if allw is not None and len(allw) > len(order):
        allo = sorted(allw, key=lambda n: tops[n]["x"]); rows = []
        for agg in ("max", "p90", "mean"):
            f = front(grid_search(allw, allo, agg))
            rows += [dict(agg=agg, target_r=t, zones=int(f[f.minR >= t].nZones.min()) if (f.minR >= t).any() else None) for t in (0.80, 0.85, 0.90)]
        pd.DataFrame(rows).to_csv(os.path.join(a.out, f"zones_needed_{len(allw)}wells.csv"), index=False)
        print(f"generalisation: {len(allw)} wells written")
    if not a.skip_flow:
        grids = PAPER_GRIDS[::3] if a.quick else PAPER_GRIDS
        R = flow_batch(wells, order, sec, grids, ncols=80 if a.quick else 400, nsteps=12 if a.quick else 50)
        R.to_csv(os.path.join(a.out, "flow_batch.csv"), index=False)
        S = summarise(R); S.to_csv(os.path.join(a.out, "flow_summary.csv"), index=False)
        print(S.round(3).to_string(index=False))
    print(f"done in {time.time()-t0:.0f} s; outputs in {a.out}/")

if __name__ == "__main__":
    main()
