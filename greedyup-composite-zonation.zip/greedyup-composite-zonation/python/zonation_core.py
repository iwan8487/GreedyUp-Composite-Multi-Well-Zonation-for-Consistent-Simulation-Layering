
"""zonation_core.py - faithful Python port of the composite multi-well zonation
and single-phase flow validation implemented in consistent_grid_explorer (JS),
with optional corrections (averaging rule, fine-grid thickness).
"""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla
KFLOOR = 1e-6; BETA_T = 0.001127; ALPHA_C = 5.615
def log2(x): return np.log2(np.maximum(np.asarray(x, float), KFLOOR))

def interp_clamp(xq, xs, ys): return np.interp(xq, xs, ys)          # np.interp clamps = JS interpClamp

def interp_extrap_linear(xq, xs, ys):
    xs = np.asarray(xs, float); ys = np.asarray(ys, float); xq = np.asarray(xq, float)
    if len(xs) == 1: return np.full_like(xq, ys[0])
    out = np.interp(xq, xs, ys)
    m0 = (ys[1]-ys[0])/(xs[1]-xs[0]); m1 = (ys[-1]-ys[-2])/(xs[-1]-xs[-2])
    out = np.where(xq <= xs[0], ys[0] + m0*(xq-xs[0]), out)
    out = np.where(xq >= xs[-1], ys[-1] + m1*(xq-xs[-1]), out)
    return out

def moving_std(sig, window):
    sig = np.asarray(sig, float); n = len(sig); half = window // 2
    left = [sig[half-i] if half-i < n else sig[0] for i in range(half)]
    right = [sig[n-2-i] if n-2-i >= 0 else sig[-1] for i in range(half)]
    pad = np.concatenate([left, sig, right])
    from numpy.lib.stride_tricks import sliding_window_view
    W = sliding_window_view(pad, window)[:n]
    return W.std(axis=1)

def resample_log2k(well, tgrid):
    tn = (np.asarray(well['depth']) - well['h2_top'])/(well['h2_base']-well['h2_top'])
    return interp_clamp(tgrid, tn, log2(well['k']))

def build_composite(wells, order, tgrid, wf, agg='max'):
    window = max(3, int(round(wf*len(tgrid))))
    het = {n: moving_std(resample_log2k(wells[n], tgrid), window) for n in order}
    H = np.vstack([het[n] for n in order])
    if agg == 'max': comp = H.max(0)
    elif agg == 'mean': comp = H.mean(0)
    else:
        s = np.sort(H, 0); comp = s[min(len(order)-1, int(np.ceil(0.9*len(order)))-1)]
    return comp, het, window

def greedy_zonation(sig, ez, lmin, lmax):
    sig = np.asarray(sig, float); n = len(sig); bounds = []; i = 0
    c1 = np.concatenate([[0], np.cumsum(sig)]); c2 = np.concatenate([[0], np.cumsum(sig**2)])
    while i < n:
        best = 0; cap = min(lmax, n-i)
        for w in range(lmin, cap+1):
            s1 = c1[i+w]-c1[i]; s2 = c2[i+w]-c2[i]; mu = s1/w
            rmse = np.sqrt(max(s2/w - mu*mu, 0.0))
            if rmse < ez: best = w
            else: break
        w = best if best > 0 else min(lmin, n-i)
        bounds.append((i, i+w-1)); i += w
    return bounds

def greedy_zonation_multi(S, ez, lmin, lmax):
    """Multivariate variant: S (nwells x n). RMSE pooled over all wells."""
    S = np.asarray(S, float); m, n = S.shape; bounds = []; i = 0
    c1 = np.concatenate([np.zeros((m,1)), np.cumsum(S,1)],1); c2 = np.concatenate([np.zeros((m,1)), np.cumsum(S**2,1)],1)
    while i < n:
        best = 0; cap = min(lmax, n-i)
        for w in range(lmin, cap+1):
            s1 = c1[:,i+w]-c1[:,i]; s2 = c2[:,i+w]-c2[:,i]; mu = s1/w
            rmse = np.sqrt(max(np.mean(s2/w - mu*mu), 0.0))
            if rmse < ez: best = w
            else: break
        w = best if best > 0 else min(lmin, n-i)
        bounds.append((i, i+w-1)); i += w
    return bounds

def _fill_gaps(rows):
    xs = np.array([(r['t0']+r['t1'])/2 for r in rows])
    for key, islog in (('PERM', True), ('POR', False)):
        v = np.array([r[key] for r in rows], float)
        v = np.where(np.isfinite(v), log2(np.where(np.isfinite(v), v, 1)) if islog else v, np.nan) if islog else v
        ok = np.isfinite(v)
        if ok.sum() == 0: continue
        lo, hi = v[ok].min(), v[ok].max()
        if (~ok).any():
            f = interp_extrap_linear(xs[~ok], xs[ok], v[ok]) if ok.sum() > 1 else np.full((~ok).sum(), v[ok][0])
            v[~ok] = np.clip(f, lo, hi)
        for r, val in zip(rows, v): r[key] = 2**val if islog else val
        for r, val in zip(rows, v):
            if islog: r['logK'] = val
    return rows

def zone_props(k, por, dz, avg):
    """avg: 'geo' (draft), 'arith' (kh arithmetic, kv harmonic)."""
    k = np.asarray(k, float); ok = np.isfinite(k) & (k > 0)
    p = np.asarray(por, float); okp = np.isfinite(p)
    if ok.sum() == 0: kh = kv = np.nan
    elif avg == 'geo': kh = kv = 2**np.mean(np.log2(k[ok]))
    else:
        kh = np.mean(k[ok]); kv = ok.sum()/np.sum(1.0/np.maximum(k[ok], KFLOOR))
    return kh, kv, (np.mean(p[okp]) if okp.any() else np.nan), int(ok.sum())

def zone_table(well, tedges, avg='geo'):
    d = np.asarray(well['depth']); k = np.asarray(well['k'], float); p = np.asarray(well['por'], float)
    top, base = well['h2_top'], well['h2_base']; nz = len(tedges)-1; rows = []
    for z in range(nz):
        md0 = top + tedges[z]*(base-top); md1 = top + tedges[z+1]*(base-top)
        m = (d >= md0) & ((d < md1) if z < nz-1 else (d <= md1))
        kh, kv, ph, n = zone_props(k[m], p[m], None, avg)
        rows.append(dict(t0=tedges[z], t1=tedges[z+1], top_md=md0, base_md=md1, thickness=md1-md0, PERM=kh, KV=kv, POR=ph, n=n))
    return _fill_kv(_fill_gaps(rows))

def _fill_kv(rows):
    # fill KV gaps by ratio to PERM of the same zone (only used when avg='arith')
    for r in rows:
        if not np.isfinite(r['KV']): r['KV'] = r['PERM']
    return rows

def fine_zone_table(well, nlayers, avg='geo', thick_fix=False, step=0.1):
    d = np.asarray(well['depth']); k = np.asarray(well['k'], float); p = np.asarray(well['por'], float); n = len(k)
    rows = []
    for z in range(nlayers):
        s = (z*n)//nlayers; e = min(n-1, ((z+1)*n)//nlayers - 1)
        if e < s:
            rows.append(dict(t0=z/nlayers, t1=(z+1)/nlayers, thickness=np.nan, PERM=np.nan, KV=np.nan, POR=np.nan, n=0)); continue
        kh, kv, ph, nn = zone_props(k[s:e+1], p[s:e+1], None, avg)
        th = (e-s+1)*step if thick_fix else d[e]-d[s]
        rows.append(dict(t0=z/nlayers, t1=(z+1)/nlayers, top_md=d[s], base_md=d[e], thickness=th, PERM=kh, KV=kv, POR=ph, n=nn))
    return _fill_kv(_fill_gaps(rows))

def pearson(a, b):
    a = np.asarray(a); b = np.asarray(b); a = a-a.mean(); b = b-b.mean()
    return float((a*b).sum()/np.sqrt((a*a).sum()*(b*b).sum()+1e-12))

def fidelity(well, rows):
    d = np.asarray(well['depth']); raw = log2(well['k'])
    base = np.array([r['base_md'] for r in rows])
    zi = np.minimum(np.searchsorted(base, d, side='right'), len(rows)-1)
    up = log2(np.array([rows[i]['PERM'] for i in zi]))
    return pearson(raw, up), float(np.sqrt(np.mean((raw-up)**2)))

def run_composite(wells, order, nT=1000, wf=0.02, ezf=0.5, lmin=5, lmax=40, agg='max', avg='geo', mode='composite'):
    tg = np.arange(nT)/(nT-1)
    comp, het, window = build_composite(wells, order, tg, wf, agg)
    if mode == 'composite':
        ez = ezf*comp.std(); b = greedy_zonation(comp, ez, lmin, lmax)
    elif mode == 'multivariate':
        S = np.vstack([resample_log2k(wells[n], tg) for n in order]); ez = ezf
        b = greedy_zonation_multi(S, ez, lmin, lmax)
    tedges = np.array([tg[x[0]] for x in b] + [1.0])
    zt = {n: zone_table(wells[n], tedges, avg) for n in order}
    fid = {n: fidelity(wells[n], zt[n]) for n in order}
    return dict(tgrid=tg, composite=comp, het=het, window=window, bounds=b, tedges=tedges, nZones=len(b), zt=zt, fid=fid)

def uniform_grid(wells, order, nz, avg='geo'):
    tedges = np.linspace(0, 1, nz+1)
    zt = {n: zone_table(wells[n], tedges, avg) for n in order}
    return dict(tedges=tedges, nZones=nz, zt=zt, fid={n: fidelity(wells[n], zt[n]) for n in order})

# ---------------------------------------------------------------- flow
def property_maps(zt, order, sec, ncols, margin_ft, thick_mode='mean'):
    nz = len(zt[order[0]]); xs = np.array([sec[n] for n in order], float)
    xmin, xmax = xs.min()-margin_ft, xs.max()+margin_ft
    colx = xmin + (xmax-xmin)*np.arange(ncols)/(ncols-1); cw = (xmax-xmin)/(ncols-1)
    kmap = np.zeros((nz, ncols)); kvmap = np.zeros((nz, ncols)); phimap = np.zeros((nz, ncols)); th = np.zeros(nz)
    for z in range(nz):
        lk = [log2(max(zt[n][z]['PERM'], KFLOOR)) for n in order]
        lkv = [log2(max(zt[n][z]['KV'], KFLOOR)) for n in order]
        ph = [zt[n][z]['POR'] for n in order]
        kmap[z] = 2**interp_extrap_linear(colx, xs, lk); kvmap[z] = 2**interp_extrap_linear(colx, xs, lkv)
        phimap[z] = np.clip(interp_extrap_linear(colx, xs, ph), 0.01, 0.45)
        th[z] = np.nanmean([zt[n][z]['thickness'] for n in order])
    wellcol = {n: int(np.argmin(np.abs(colx-sec[n]))) for n in order}
    return dict(kmap=kmap, kvmap=kvmap, phimap=phimap, th=th, colx=colx, cw=cw, wellcol=wellcol)

def assemble(M, width=500.0, mu=1.0):
    k, kv, th, cw = M['kmap'], M['kvmap'], M['th'], M['cw']; nz, nc = k.shape; N = nz*nc
    idx = np.arange(N).reshape(nz, nc)
    A = th[:, None]*width
    kx = 2*k[:, :-1]*k[:, 1:]/(k[:, :-1]+k[:, 1:])
    Tx = BETA_T*kx*A/(mu*cw)
    dz = 0.5*(th[:-1]+th[1:])[:, None]
    kz = 2*kv[:-1]*kv[1:]/(kv[:-1]+kv[1:])
    Tz = BETA_T*kz*(cw*width)/(mu*dz)
    I = np.concatenate([idx[:, :-1].ravel(), idx[:-1, :].ravel()])
    J = np.concatenate([idx[:, 1:].ravel(), idx[1:, :].ravel()])
    T = np.concatenate([Tx.ravel(), Tz.ravel()])
    off = sp.coo_matrix((-T, (I, J)), shape=(N, N)); off = off + off.T
    Tsum = -np.asarray(off.sum(1)).ravel()
    return off.tocsc(), Tsum, idx

def simulate(M, producer_sets, rate=-100.0, mu=1.0, ct=1e-5, p0=5000.0, width=500.0, t0=0.05, t1=2000.0, nsteps=50):
    """Solve all producer combinations simultaneously (one LU per time step)."""
    off, Tsum, idx = assemble(M, width, mu); nz, nc = M['kmap'].shape; N = nz*nc
    acc0 = (M['th'][:, None]*M['cw']*width*M['phimap']*ct/ALPHA_C).ravel()
    wells = list(M['wellcol']); ncomb = len(producer_sets)
    Q = np.zeros((N, ncomb))
    for c, ps in enumerate(producer_sets):
        for w in ps:
            j = M['wellcol'][w]; kh = M['kmap'][:, j]*M['th']
            Q[idx[:, j], c] += rate*kh/kh.sum()
    times = t0*(t1/t0)**(np.arange(nsteps)/(nsteps-1)); dts = np.diff(np.concatenate([[0], times]))
    P = np.full((N, ncomb), p0); hist = {w: np.zeros((nsteps, ncomb)) for w in wells}
    for s, dt in enumerate(dts):
        acc = acc0/dt
        A = (off + sp.diags(acc+Tsum)).tocsc()
        lu = spla.splu(A, permc_spec='MMD_AT_PLUS_A')
        P = lu.solve(acc[:, None]*P + Q)
        for w in wells:
            j = M['wellcol'][w]; kh = M['kmap'][:, j]*M['th']
            hist[w][s] = (kh[:, None]*P[idx[:, j]]).sum(0)/kh.sum()
        del lu
    return times, hist
