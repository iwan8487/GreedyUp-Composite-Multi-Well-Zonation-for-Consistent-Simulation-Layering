# Data

Place the input data here before running the LAS-based pipeline:

```
data/
├── welltop.txt          # Well identifier, Surface, X, Y, Z, MD (H2 Top / H2 Base)
└── las/
    ├── HW-3.las
    ├── ...
    └── HW-32.las        # one LAS 2.0 file per well: DEPT (ft), CORE_PERM (mD), CORE_POR (fraction)
```

The core data of the 17 wells are not included in this repository by default. Add them only if the data owner permits redistribution; otherwise state the access conditions here. The four-well demo data set used in the paper is embedded in `app/consistent_grid_explorer.html`, and `python/reproduce_results.py --app-html` reproduces the paper's four-well results from it.
